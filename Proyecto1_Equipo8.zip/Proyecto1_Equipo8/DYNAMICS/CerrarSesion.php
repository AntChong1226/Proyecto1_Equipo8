<?php
  session_unset();
  session_destroy();
  header("location:../TEMPLATES/Maquetado.html")
?>
